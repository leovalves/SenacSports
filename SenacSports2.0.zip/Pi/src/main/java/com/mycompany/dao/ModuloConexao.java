/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dao;
import java.sql.*;
import javax.swing.JOptionPane;


public class ModuloConexao {
    

    public Connection Conector(){
    Connection conexao = null;
   
    String nomeBD = "db_senacsports";
    String URL = "jdbc:mysql://localhost :3306/" + nomeBD;
    String login = "root";
    String senha = "";
    
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        conexao = DriverManager.getConnection(URL, login, senha);
        Statement comandoSQL = conexao.createStatement();
        JOptionPane.showMessageDialog(null, "Banco de dados Conectado com sucesso!");
        return conexao;
    }catch(ClassNotFoundException e){
        JOptionPane.showMessageDialog(null, "Driver nao ecnontrado");
        return null;
    }catch(SQLException e){
         JOptionPane.showMessageDialog(null, "Erro " + e.getMessage());
         return null;
    }
    }
}


